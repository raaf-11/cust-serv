import { useState } from "react";

export default function ChatInput({
    onSend,
    disabled = false,
}) {
    const [message, setMessage] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!message.trim()) return;

        onSend(message);

        setMessage("");
    };

    return (
        <form
            onSubmit={handleSubmit}
            className="chat-input-form"
        >
            <input
                type="text"
                placeholder="Ask about your account, orders, or policies..."
                value={message}
                disabled={disabled}
                onChange={(e) =>
                    setMessage(e.target.value)
                }
                className="chat-input"
            />

            <button
                type="submit"
                disabled={disabled || !message.trim()}
                className="chat-send-button"
                title="Send message"
            >
                ↑
            </button>
        </form>
    );
}
